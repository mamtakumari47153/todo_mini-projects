from django.urls import path
from django.contrib.auth import views as auth_views
from .views import (
    index, remove, update, toggle_completed,
    login_view, logout_view, signup_view
)

urlpatterns = [
    path('', index, name='index'),
    path('delete/<int:item_id>/', remove, name='delete'),
    path('update/<int:item_id>/', update, name='update'),
    path('toggle/<int:item_id>/', toggle_completed, name='toggle_completed'),
    path('signup/', signup_view, name='signup'),
    path('login/', login_view, name='login'),
    path('logout/', logout_view, name='logout'),

    # ... other URLs ...
    path('password_reset/', auth_views.PasswordResetView.as_view(template_name='todo_app/password_reset.html'), name='password_reset'),
    path('password_reset/done/', auth_views.PasswordResetDoneView.as_view(template_name='todo_app/password_reset_done.html'), name='password_reset_done'),
    path('reset/<uidb64>/<token>/', auth_views.PasswordResetConfirmView.as_view(template_name='todo_app/password_reset_confirm.html'), name='password_reset_confirm'),
    path('reset/done/', auth_views.PasswordResetCompleteView.as_view(template_name='todo_app/password_reset_complete.html'), name='password_reset_complete'),


]
