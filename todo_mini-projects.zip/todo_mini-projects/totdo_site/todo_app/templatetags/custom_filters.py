from django import template

register = template.Library()

@register.filter
def abs_val(value):
    try:
        return abs(int(value))
    except (ValueError, TypeError):
        return value  # fallback if value is not convertible

@register.filter(name='add_class')
def add_class(field, css_class):
    return field.as_widget(attrs={'class': css_class})
