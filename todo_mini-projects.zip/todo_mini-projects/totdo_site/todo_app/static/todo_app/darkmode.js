document.addEventListener("DOMContentLoaded", function () {
  const toggle = document.getElementById('darkToggle');
  const body = document.body;

  if (localStorage.getItem('darkMode') === 'true') {
    body.classList.add('dark-mode');
    toggle.checked = true;
  }

  if (toggle) {
    toggle.addEventListener('change', () => {
      body.classList.toggle('dark-mode');
      localStorage.setItem('darkMode', toggle.checked);
    });
  }
});
