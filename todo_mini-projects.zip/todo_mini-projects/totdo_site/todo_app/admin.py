from django.contrib import admin
from .models import CustomUser, Todo_List
from django.contrib.auth.admin import UserAdmin
from django.utils.translation import gettext_lazy as _

# ✅ Custom filter to filter tasks by user_type (via related user)
class UserTypeFilter(admin.SimpleListFilter):
    title = _('User Type')
    parameter_name = 'user_type'

    def lookups(self, request, model_admin):
        return CustomUser.USER_TYPE_CHOICES

    def queryset(self, request, queryset):
        if self.value():
            return queryset.filter(user__user_type=self.value())
        return queryset


@admin.register(CustomUser)
class CustomUserAdmin(UserAdmin):
    fieldsets = UserAdmin.fieldsets + (
        ('Additional Info', {'fields': ('user_type',)}),
    )
    add_fieldsets = UserAdmin.add_fieldsets + (
        ('Additional Info', {'fields': ('user_type',)}),
    )
    list_display = ['username', 'email', 'first_name', 'last_name', 'user_type', 'is_staff']


@admin.register(Todo_List)
class TodoListAdmin(admin.ModelAdmin):
    list_display = ['title', 'user', 'priority', 'due_date', 'completed']
    list_filter = ['completed', 'priority', 'user', UserTypeFilter]  # ✅ fixed here
    search_fields = ['title', 'description']
