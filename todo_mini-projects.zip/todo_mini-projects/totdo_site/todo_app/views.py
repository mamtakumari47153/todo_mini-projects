from django.shortcuts import render, redirect,get_object_or_404
from .forms import TodoForm
from datetime import date
from datetime import timedelta
from .models import Todo_List
from .forms import CustomSignupForm
from django.contrib.auth import authenticate, login
from django.contrib.auth.forms import AuthenticationForm
from django.contrib import messages
from django.contrib.auth import logout
from django.contrib.auth.decorators import login_required
from django.contrib.auth import views as auth_views



@login_required
def index(request):
    item_list = Todo_List.objects.filter(user=request.user).order_by("-date")
    form = TodoForm(request.POST or None)

    # 🔍 Search & Filter
    query = request.GET.get('q')
    filter_status = request.GET.get('status')
    if query:
        item_list = item_list.filter(title__icontains=query)
    if filter_status == 'completed':
        item_list = item_list.filter(completed=True)
    elif filter_status == 'pending':
        item_list = item_list.filter(completed=False)

    # ✅ Save task and set the logged-in user
    if request.method == "POST" and form.is_valid():
        todo = form.save(commit=False)
        todo.user = request.user
        todo.save()
        return redirect('index')

    context = {
        "today": date.today(),
        "forms": form,
        "list": item_list,
        "title": "TODO LIST",
        "query": query,
        "status": filter_status,
        "update": False,
        "progress_percent": ...,
        "completed_weekly": ...,
        "total_weekly": ...
    }
    return render(request, 'todo_app/index.html', context)





def remove(request, item_id):
    item = Todo_List.objects.get(id=item_id)
    item.delete()
    messages.info(request, "Task removed!")
    return redirect('index')


def update(request, item_id):
    item = get_object_or_404(Todo_List, id=item_id)
    form = TodoForm(request.POST or None, instance=item)

    if form.is_valid():
        form.save()
        messages.success(request, "Task updated successfully!")
        return redirect('index')

    context = {
        "forms": form,
        "title": "Update Task",
        "update": True,
        "item_id": item_id,
    }
    return render(request, 'todo_app/index.html', context)


def toggle_completed(request, item_id):
    item = get_object_or_404(Todo_List, id=item_id)
    item.completed = not item.completed
    item.save()
    return redirect('index')


def signup_view(request):
    if request.method == 'POST':
        form = CustomSignupForm(request.POST)
        if form.is_valid():
            user = form.save()
            login(request, user)
            return redirect('index')
    else:
        form = CustomSignupForm()
    return render(request, 'todo_app/signup.html', {'form': form})



def login_view(request):
    if request.method == 'POST':
        form = AuthenticationForm(request, data=request.POST)
        if form.is_valid():
            user = form.get_user()
            login(request, user)
            messages.success(request, f"Welcome back, {user.username}!")
            return redirect('index')  # Or redirect based on user_type if needed
        else:
            messages.error(request, "Invalid username or password.")
    else:
        form = AuthenticationForm()
    return render(request, 'todo_app/login.html', {'form': form})


def logout_view(request):
    logout(request)
    messages.success(request, "You have been logged out.")
    return render(request, 'todo_app/logout.html')