from django.db import models
from django.utils import timezone
from django.contrib.auth.models import AbstractUser
from django.conf import settings  # for referencing CustomUser safely

# 🔐 Custom User Model
class CustomUser(AbstractUser):
    USER_TYPE_CHOICES = [
        ('student', 'Student'),
        ('employee', 'Employee'),
        ('housekeeper', 'Housekeeper'),
        ('freelancer', 'Freelancer'),
        ('parent', 'Parent'),
    ]

    user_type = models.CharField(max_length=20, choices=USER_TYPE_CHOICES, default='student')

    def __str__(self):
        return self.username

# 📋 Todo List Model
class Todo_List(models.Model):
    PRIORITY_CHOICES = [
        ('High', 'High'),
        ('Medium', 'Medium'),
        ('Low', 'Low'),
    ]
    user = models.ForeignKey(settings.AUTH_USER_MODEL, on_delete=models.CASCADE)
    title = models.CharField("Task Title", max_length=100)
    description = models.TextField("Description", default="No description")
    date = models.DateTimeField("Created At", default=timezone.now)
    due_date = models.DateField("Due Date", null=True, blank=True)
    completed = models.BooleanField("Completed", default=False)
    priority = models.CharField(max_length=10, choices=PRIORITY_CHOICES, default='Medium')

    # ✅ Link each task to a user
    user = models.ForeignKey(settings.AUTH_USER_MODEL, on_delete=models.CASCADE, null=True)

    def __str__(self):
        return self.title

    class Meta:
        ordering = ['-date']
