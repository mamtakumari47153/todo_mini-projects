# 📝 Django TODO List Web Application

A feature-rich task management web app built using **Django**, **Bootstrap**, and **SQLite/MySQL**, designed to help users stay organized with tasks, priorities, deadlines, and progress tracking — with authentication and dark mode!

---

## 🚀 Features

- 🔐 **User Authentication**
  - Sign up, login, logout
  - Password reset via email
  - Personalized greeting and user type

- ✅ **Task Management**
  - Add, update, delete tasks
  - Set title, description, due date, and priority
  - Mark tasks as completed or pending
  - Filter/search tasks by status or keyword

- 📅 **Due Date Tracker**
  - Countdown for tasks: “3 days left”, “Overdue”
  - Highlight tasks based on due date

- 📊 **Weekly Progress**
  - Progress bar showing completed tasks this week

- 🌙 **Dark Mode**
  - Toggle between light and dark themes (saved in browser)

- 🔍 **User Type Filtering**
  - Filter tasks by role: Student, Employee, Housekeeper, Freelancer, Parent

- 📂 **Clean UI**
  - Sticky-note style cards for each task
  - Responsive and elegant layout with Bootstrap

---

## 📁 Project Structure

totdo_site/
│
├── todo_app/
│ ├── migrations/
│ ├── templates/todo_app/
│ ├── static/
│ │ ├── css/styles.css
│ │ └── js/darkmode.js
│ ├── templatetags/custom_filters.py
│ ├── models.py
│ ├── views.py
│ ├── forms.py
│ └── urls.py
│
├── totdo_site/
│ ├── settings.py
│ ├── urls.py
│ └── wsgi.py
│
├── manage.py
└── README.md


---

## ⚙️ Setup Instructions

1. **Clone the project**:

```bash
git clone https://github.com/your-username/todo-app.git
cd todo-app

2.Create virtual environment:
python -m venv venv
source venv/bin/activate  # For Windows: venv\Scripts\activate

3.Install dependencies:
pip install -r requirements.txt

4.Apply migrations:
python manage.py makemigrations
python manage.py migrate

5.Run the server:
python manage.py runserver

📧 Email Setup (For Forgot Password)
In settings.py, add your email credentials:
EMAIL_BACKEND = 'django.core.mail.backends.smtp.EmailBackend'
EMAIL_HOST = 'smtp.gmail.com'
EMAIL_PORT = 587
EMAIL_USE_TLS = True
EMAIL_HOST_USER = 'your_email@gmail.com'
EMAIL_HOST_PASSWORD = 'your_app_password'

🛠 Tech Stack
Python 3.x

Django 4.x

SQLite (default) or MySQL

Bootstrap 3

HTML, CSS, JS

🙋‍♂️ Author
Mamta Kumari
Backend Developer | Python & Django Enthusiast
📍 East Delhi | 🌐 LinkedIn

📜 License
This project is for learning and personal use only. All rights reserved.

